function haoyemao_create_code()
{
    var taget=document.getElementsByClassName("haoyemao_code_box");
    var i;
    haoyemao_codes = new Array();
    fresh = new Array();
    for (i = 0; i < taget.length; i++) {
        haoyemao_codes[i] = new haoyemao_code(i);
        fresh.push(i);//队列依次处理
    }
    i = 0;
    haoyemao_codes[fresh[0]].reset(fresh);
    hym_error_repeat = 3;
}
class haoyemao_code
{
    constructor(index){
        this.index = index;
    }
    reset(fresh)
    {
        $.ajax({
            type: "POST", //提交的方法
            async: true, //异步
            url:"./get_code.php", //提交的地址
            data:
            {
                'index':this.index,
            },// 序列化表单值
            dataType:'json',
            timeout: 4000,
            success:function(data)
            {
                if(data.error == 1){
                    alert("签名验证失败");
                }
                else if(data.error == -100){
                    alert("接口剩余调用次数不足！");
                }
                else
                {
                    document.getElementsByClassName("haoyemao_code_box")[data.index].innerHTML='<img class="haoyemao_code_img" src="data:image/png;base64,'+ (data.img).replace(/\\\//g, '/') +'"/>\
                    <input class="haoyemao_code_data" style="display:none;" value="'+ md5(data.code) +'"/>\
                    ';
                    //防止拥堵。
                    fresh.shift();
                    if(fresh.length)
                    {
                        haoyemao_codes[fresh[0]].reset(fresh);
                    }
                }
            },
            error:function(data)
            {
                alert("验证码错误！");
            }
        });
    }
    //验证是否正确，正确返回1
    check(input)
    {
        var getdata = document.getElementsByClassName("haoyemao_code_data")[this.index].value;
        if(md5(input.toLowerCase()) == getdata)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}