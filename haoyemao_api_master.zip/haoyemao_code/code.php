<?php $a="123";?>
<html>
    <META HTTP-EQUIV="pragma" CONTENT="no-cache"> 
    <script type='text/javascript' src="./haoyemao-code.js"></script>
    <script type='text/javascript' src='./jquery/jquery.js'></script>
    <script type='text/javascript' src='./jquery/jquery.cookie.js'></script>
    <script type='text/javascript' src='./md5.js'></script>
    <!--无效输入框-->
    <input type="text" class="haoyemao_code_input" />
    <!--有效输入框-->
    <input type="text" class="haoyemao_code_input" id="thisinput" />
    <div id="sub">sub</div>
    <!--一定要有类-->
    <div class="haoyemao_code_box">
        <img class="haoyemao_code_img"/>
    </div>
    <div class="haoyemao_code_box">
        <img class="haoyemao_code_img"/>
    </div>
    <div class="haoyemao_code_box">
        <img class="haoyemao_code_img"/>
    </div>
    <script>
        haoyemao_create_code();//使用方法
        $(document).on('click','#sub',function()
        {
            var get_object = $('#thisinput');//获取input对象
            var input = get_object.val();
            var index = get_object.index('.haoyemao_code_input');//获取组号
            alert(haoyemao_codes[index].check(input));
        });
        $(document).on('click','.haoyemao_code_img',function()
        {
            var index = $('.haoyemao_code_img').index(this);
            fresh.push(index);
            haoyemao_codes[index].reset(fresh);
        });
    </script>
</html>