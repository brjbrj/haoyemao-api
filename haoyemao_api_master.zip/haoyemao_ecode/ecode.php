<html>
<head>
    <meta charset="utf-8">
    <script type="text/javascript" src="http://api.haoyemao.com/assets/js/jquery.js"></script>
    <script type="text/javascript" src="http://api.haoyemao.com/assets/others/layer/layer.js"></script>
    <title>好耶猫API</title>
    <style>
        #e-code
        {
            height:40px;
            line-height:38px;
            max-width:100%;
            margin-left:5%;
            background-color:rgba(191, 120, 58,0.3);
            border-radius:7px;
            color:#fff;
            border-color:rgba(167, 56, 54,1);
            border-style:solid;
            box-sizing:border-box;
            border-width:2px;
            font-size:12px;
            outline:none;
            text-align:center;
        }
    </style>
</head>
<body>
    <div class="form-item">
        <div style="float:left;height:40px;width:30%;">
            <div id="e-code">获取验证码</div>
        </div>
    </div>
    <script>
    //邮箱验证码发送
    $(function(){
        $('#e-code').click(function()
        {
        var email = "773867006@qq.com";
        $.ajax({
            type:"POST",    //提交的方法
            async:true,    //异步
            url:"./get_ecode.php",    //提交的地址
            data:
            {
                'to':email,
            },//    序列化表单值
            dataType:'json',
            timeout:4000,
            success:function(data)
            {
                var msg = data.msg;
                switch(msg)
                {
                    case 0:
                        layer.msg("发送失败");
                        break;
                    case 1:
                        layer.msg('发送成功',{icon:1,time:2000,shade:0.4});
                        break;
                    case -1:
                        layer.msg("邮箱不正确");
                        break;
                    case -2:
                        layer.msg("签名不正确");
                        break;
                    case -100:
                        layer.msg("接口剩余调用次数不足！");
                        break;
                    default:
                        layer.msg("未知的异常");
                        break;
                        }
                        ecode = data.code;//获取验证码的md5值
            },
            error:function(data)
            {
                layer.msg("邮箱验证码接口错误");
            }
            });
        });
    });
    </script>
</body>
</html>